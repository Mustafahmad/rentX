package com.example.rentxapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;

import com.example.rentxapplication.adaptor.bikeAdaptor;
import com.example.rentxapplication.adaptor.carAdaptor;
import com.example.rentxapplication.models.bikeModels;
import com.example.rentxapplication.models.carModels;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class rentCar extends AppCompatActivity {


    ArrayList<carModels> carList = new ArrayList<>();
    FloatingActionButton uploadBtn;
    DatabaseReference databaseReference;
    ValueEventListener eventListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rent_car);
        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        uploadBtn = findViewById(R.id.uploadBtn);
        uploadBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), uploadCar.class);
                startActivity(intent);
            }
        });

        RecyclerView carRecycler = findViewById(R.id.car_recyclerView);
        carRecycler.setLayoutManager(new LinearLayoutManager(this));

        AlertDialog.Builder builder = new AlertDialog.Builder(rentCar.this);
        builder.setCancelable(false);
        builder.setView(R.layout.progress_layout);
        AlertDialog dialog = builder.create();
        dialog.show();

        // here we make the object of the model class and then we initialize that object with the constructor
        // bikeModels model = new bikeModels(R.drawable.cd70_2, "a","111","lahore");
        //ArrayList<bikeModels> list =new ArrayList<>();

        carList.add(new carModels(R.drawable.honda_civic,"Honda Civic ","7000/Day","Township"));
        carList.add(new carModels(R.drawable.toyotacar,"Toyota Corolla ","5000/Day","Green Town"));
        carList.add(new carModels(R.drawable.vitz,"Toyota Vitz","4000/Day","Barkat Market"));
        carList.add(new carModels(R.drawable.suzukimehro,"Suzuki Mehran","3000/Day","Township"));
        carList.add(new carModels(R.drawable.suzuki_cultus,"Suzuki Cultus","3500/Day","Wapda Town"));
        carList.add(new carModels(R.drawable.alto,"SUZUKI Alto","3000/Day","Akbar Chowk"));
        carList.add(new carModels(R.drawable.toyotafortuner,"Toyota Fortuner","10000/Day","College Road"));

       /* bikeAdaptor adaptor = new bikeAdaptor(list);
        bikeRecycler.setAdapter(adaptor);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        bikeRecycler.setLayoutManager(linearLayoutManager); */
        // bikeRecycler.setLayoutManager(new LinearLayoutManager(this));
        // bikeRecycler.setAdapter(new bikeAdaptor(list));
        carAdaptor adaptor = new carAdaptor(this,carList);
        carRecycler.setAdapter(adaptor);
        databaseReference = FirebaseDatabase.getInstance().getReference("Cars Category");
        dialog.show();
        eventListener = databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                carList.clear();
                for (DataSnapshot itemSnapshot: snapshot.getChildren()){
                    carModels carModels = itemSnapshot.getValue(carModels.class);
                    carModels.setKey(itemSnapshot.getKey());
                    carList.add(carModels);
                }
                adaptor.notifyDataSetChanged();
                dialog.dismiss();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                dialog.dismiss();
            }
        });


    }

}