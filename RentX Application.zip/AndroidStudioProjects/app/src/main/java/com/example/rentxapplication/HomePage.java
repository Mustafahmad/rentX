package com.example.rentxapplication;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;


import com.google.firebase.auth.FirebaseAuth;

public class HomePage extends AppCompatActivity {

    FirebaseAuth auth;
    Button button, contactus, about;
    TextView car,bike,property,appliances,clothes,others;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);
        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        car = findViewById(R.id.rentacar);
        auth = FirebaseAuth.getInstance();

        button = findViewById(R.id.signOut);
        button.setBackgroundColor(Color.BLACK);
        button.setTextColor(Color.WHITE);

        contactus =findViewById(R.id.contactus);
        contactus.setBackgroundColor(Color.BLACK);
        contactus.setTextColor(Color.WHITE);

        about =findViewById(R.id.aboutus);
        about.setBackgroundColor(Color.BLACK);
        about.setTextColor(Color.WHITE);

        bike = findViewById(R.id.rentabike);
        property = findViewById(R.id.rentproperty);
        appliances = findViewById(R.id.rentAppliances);
        clothes = findViewById(R.id.rentclothes);
        others = findViewById(R.id.rentothers);


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
                finish();
            }
        });

        contactus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),cantactUs.class);
                startActivity(intent);
            }
        });

        about.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),AboutUs.class);
                startActivity(intent);
            }
        });

        car.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),rentCar.class);
                startActivity(intent);
            }
        });
       bike.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),rentBike.class);
                startActivity(intent);
            }
        });
        appliances.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),rentAppliances.class);
                startActivity(intent);
            }
        });
        clothes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),rentClothes.class);
                startActivity(intent);
            }
        });
       property.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),rentProperty.class);
                startActivity(intent);
            }
        });
        /*others.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),rentOthers.class);
                startActivity(intent);
            }
        });
        */


    }


}
